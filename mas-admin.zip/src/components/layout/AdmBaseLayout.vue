<template>
  <v-app>
    <!-- header -->
    <adm-the-header @select-menu="selMenu" />

    <!-- aside menu -->
    <adm-the-aside :menu-idx="selMenuIdx" />

    <!-- main -->
    <v-main>
      <router-view />
    </v-main>
  </v-app>
</template>

<script setup>
import { ref } from 'vue';
import AdmTheHeader from '@/components/layout/AdmTheHeader.vue';
import AdmTheAside from '@/components/layout/AdmTheAside.vue';

const selMenuIdx = ref(0);
const selMenu = (v) => {
  console.log(v)

  selMenuIdx.value = v;
};
</script>
