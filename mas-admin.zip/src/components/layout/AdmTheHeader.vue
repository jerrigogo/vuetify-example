<template>
  <v-app-bar class="border-b px-md-4" flat>
    <template v-slot:prepend>
      <h1 class="logo" @click="selMenu(0)">MAS ADMIN</h1>
    </template>

    <template v-slot:append>
      <div class="header-btns">
        <v-btn @click="selMenu(0)">Menu1</v-btn>
        <v-btn @click="selMenu(1)">Menu2</v-btn>
        <v-btn @click="selMenu(2)">Menu3</v-btn>
        <v-btn @click="selMenu(3)">Menu4</v-btn>
        <v-btn @click="selMenu(4)">Menu5</v-btn>
        <v-btn @click="selMenu(5)">Menu6</v-btn>
      </div>
    </template>
  </v-app-bar>
</template>

<script setup>
import router from '@/router';

const emits = defineEmits(['selectMenu']);
const selMenu = (idx) => {
  emits('selectMenu', idx);

  // 페이지 이동
  router.push({ path: '/' });
}
</script>

<style scope>
.logo {
  position: relative;
  font-size: 16px;
}
</style>