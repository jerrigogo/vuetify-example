<template>
  <v-navigation-drawer class="px-md-4 py-md-5">
    <v-list-item v-for="(item, index) in subMenus[props.menuIdx]" :key="index">
      <router-link :to="item.path">{{ item.label }}</router-link>
    </v-list-item>
  </v-navigation-drawer>
</template>

<script setup>
import { reactive } from 'vue';
import subMenuList from '@/components/layout/AdmAsideMenu.json';

const props = defineProps({
  menuIdx: { type: Number }
});

const subMenus = reactive(subMenuList);

</script>
