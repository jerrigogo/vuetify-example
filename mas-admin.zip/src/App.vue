<template>
  <router-view />
</template>

<script setup>
import { RouterView } from 'vue-router';
</script>
